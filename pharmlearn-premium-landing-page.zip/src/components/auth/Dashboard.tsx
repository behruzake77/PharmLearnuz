import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  GraduationCap, LogOut, BookOpen, Award, Clock, TrendingUp,
  Play, Star, ChevronRight, Bell, Settings, Search,
  BarChart3, Target, Flame, Calendar, User,
  Menu, X,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface DashboardProps {
  onNavigate: (page: 'landing' | 'login' | 'register' | 'dashboard') => void;
}

const courses = [
  {
    title: 'Farmakologiya asoslari',
    progress: 68,
    lessons: '32/48',
    image: 'https://images.pexels.com/photos/8667961/pexels-photo-8667961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=400',
    nextLesson: 'Dori o\'zaro ta\'siri',
    rating: 4.9,
  },
  {
    title: 'Klinik farmatsiya',
    progress: 35,
    lessons: '22/64',
    image: 'https://images.pexels.com/photos/8666446/pexels-photo-8666446.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=400',
    nextLesson: 'Dozalash tamoyillari',
    rating: 4.8,
  },
  {
    title: 'Farmatsevtik texnologiya',
    progress: 12,
    lessons: '7/56',
    image: 'https://images.pexels.com/photos/3772620/pexels-photo-3772620.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=400',
    nextLesson: 'Tabletka ishlab chiqarish',
    rating: 4.9,
  },
];

const activities = [
  { text: '"Farmakologiya asoslari" kursida 32-darsni tugatdingiz', time: '2 soat oldin', icon: BookOpen },
  { text: 'Yangi sertifikat olish uchun 16 dars qoldi', time: '5 soat oldin', icon: Award },
  { text: '7 kunlik o\'rganish seriyangiz davom etmoqda! 🔥', time: 'Bugun', icon: Flame },
  { text: 'Yangi kurs qo\'shildi: "Dori shakllari texnologiyasi"', time: 'Kecha', icon: Star },
];

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    onNavigate('landing');
  };

  const initials = user?.fullName
    ?.split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'PL';

  const stats = [
    { label: 'Boshlangan kurslar', value: '3', icon: BookOpen, color: 'from-primary-500 to-primary-600', bg: 'bg-primary-50' },
    { label: 'Tugatilgan darslar', value: '61', icon: Target, color: 'from-emerald-500 to-emerald-600', bg: 'bg-emerald-50' },
    { label: 'O\'rganish soatlari', value: '47', icon: Clock, color: 'from-amber-500 to-orange-500', bg: 'bg-amber-50' },
    { label: 'Seriya (kunlar)', value: '7', icon: Flame, color: 'from-rose-500 to-pink-500', bg: 'bg-rose-50' },
  ];

  return (
    <div className="min-h-screen bg-dark-50 flex">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-72 bg-white border-r border-dark-100 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:flex-shrink-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-dark-100">
            <a onClick={() => onNavigate('landing')} className="flex items-center gap-2.5 cursor-pointer group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-600 to-emerald-500 flex items-center justify-center shadow-md shadow-primary-500/20">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-dark-900 tracking-tight">
                Pharm<span className="gradient-text">Learn</span>
              </span>
            </a>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg text-dark-400 hover:bg-dark-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Nav items */}
          <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
            {[
              { icon: BarChart3, label: 'Dashboard', active: true },
              { icon: BookOpen, label: 'Mening kurslarim', active: false },
              { icon: Calendar, label: 'Jadval', active: false },
              { icon: Award, label: 'Sertifikatlar', active: false },
              { icon: TrendingUp, label: 'Taraqqiyot', active: false },
              { icon: Star, label: 'Sevimlilar', active: false },
            ].map((item) => (
              <button
                key={item.label}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  item.active
                    ? 'bg-primary-50 text-primary-700 shadow-sm'
                    : 'text-dark-500 hover:text-dark-700 hover:bg-dark-50'
                }`}
              >
                <item.icon className="w-4.5 h-4.5" />
                {item.label}
              </button>
            ))}
          </nav>

          {/* Bottom */}
          <div className="p-4 border-t border-dark-100 space-y-1">
            <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-dark-500 hover:text-dark-700 hover:bg-dark-50 transition-all">
              <Settings className="w-4.5 h-4.5" />
              Sozlamalar
            </button>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:text-red-600 hover:bg-red-50 transition-all"
            >
              <LogOut className="w-4.5 h-4.5" />
              Chiqish
            </button>
          </div>
        </div>
      </aside>

      {/* Sidebar overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/20 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main content */}
      <main className="flex-1 min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-xl border-b border-dark-100 h-16 flex items-center px-4 sm:px-6 lg:px-8 gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl text-dark-500 hover:bg-dark-100"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
              <input
                type="text"
                placeholder="Kurslarni qidirish..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-dark-50 border border-dark-200 text-sm text-dark-900 placeholder:text-dark-400 focus:bg-white focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="relative w-9 h-9 flex items-center justify-center rounded-xl text-dark-500 hover:bg-dark-100 transition-colors">
              <Bell className="w-5 h-5" />
              <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <div className="h-6 w-px bg-dark-200 hidden sm:block" />
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-500 to-emerald-500 flex items-center justify-center text-white text-xs font-bold shadow-md">
                {initials}
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-semibold text-dark-900 leading-none">{user?.fullName}</p>
                <p className="text-xs text-dark-400 mt-0.5">{user?.role}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-4 sm:p-6 lg:p-8 max-w-6xl">
          {/* Welcome */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-2xl sm:text-3xl font-extrabold text-dark-900 mb-2">
              Xush kelibsiz, {user?.fullName?.split(' ')[0]}! 👋
            </h1>
            <p className="text-sm text-dark-500">
              Bugungi o'rganish maqsadlaringizga erishishga tayyor bo'ling.
            </p>
          </motion.div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="bg-white rounded-2xl border border-dark-100 p-4 sm:p-5 hover:shadow-lg hover:shadow-primary-500/[0.04] transition-shadow duration-300"
              >
                <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                  <div className={`w-5 h-5 bg-gradient-to-br ${stat.color} rounded-md flex items-center justify-center`}>
                    <stat.icon className="w-3 h-3 text-white" />
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-extrabold text-dark-900">{stat.value}</p>
                <p className="text-xs text-dark-400 mt-0.5">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          {/* Main grid */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Courses - takes 2 cols */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-dark-900">Davom etayotgan kurslar</h2>
                <button className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center gap-1">
                  Barchasi <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {courses.map((course, i) => (
                <motion.div
                  key={course.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.08 }}
                  className="group bg-white rounded-2xl border border-dark-100 overflow-hidden hover:shadow-lg hover:border-primary-200 transition-all duration-300"
                >
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-40 lg:w-48 h-32 sm:h-auto overflow-hidden flex-shrink-0">
                      <img
                        src={course.image}
                        alt={course.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="flex-1 p-4 sm:p-5 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <h3 className="text-base font-bold text-dark-900 group-hover:text-primary-700 transition-colors">
                            {course.title}
                          </h3>
                          <div className="flex items-center gap-1">
                            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                            <span className="text-xs font-semibold text-dark-700">{course.rating}</span>
                          </div>
                        </div>
                        <p className="text-xs text-dark-400 mb-3">
                          Keyingi dars: <span className="font-medium text-dark-600">{course.nextLesson}</span>
                        </p>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-xs font-medium text-dark-500">{course.lessons} dars</span>
                          <span className="text-xs font-bold text-primary-600">{course.progress}%</span>
                        </div>
                        <div className="w-full h-2 bg-dark-100 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${course.progress}%` }}
                            transition={{ duration: 1, delay: 0.5 + i * 0.2 }}
                            className="h-full bg-gradient-to-r from-primary-500 to-emerald-500 rounded-full"
                          />
                        </div>
                        <div className="mt-3 flex items-center justify-between">
                          <button className="group/btn inline-flex items-center gap-1.5 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold rounded-lg transition-all shadow-sm hover:shadow-md">
                            <Play className="w-3.5 h-3.5" />
                            Davom etish
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Activity feed */}
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-dark-900">So'nggi faoliyat</h2>
              <div className="bg-white rounded-2xl border border-dark-100 divide-y divide-dark-100">
                {activities.map((activity, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.08 }}
                    className="p-4 flex gap-3 hover:bg-dark-50/50 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-lg bg-primary-50 flex items-center justify-center flex-shrink-0">
                      <activity.icon className="w-4 h-4 text-primary-600" />
                    </div>
                    <div>
                      <p className="text-sm text-dark-700 leading-snug">{activity.text}</p>
                      <p className="text-xs text-dark-400 mt-1">{activity.time}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Quick actions */}
              <div className="bg-gradient-to-br from-primary-600 to-primary-700 rounded-2xl p-5 text-white">
                <div className="flex items-center gap-2 mb-3">
                  <Flame className="w-5 h-5 text-amber-300" />
                  <span className="text-sm font-bold">7 kunlik seriya!</span>
                </div>
                <p className="text-sm text-primary-100/80 mb-4">
                  Ajoyib! Har kuni o'rganishda davom etib, o'z rekordingizni yangilang.
                </p>
                <div className="flex gap-1.5">
                  {['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'].map((day, i) => (
                    <div
                      key={day}
                      className={`w-full aspect-square rounded-lg flex items-center justify-center text-[10px] font-bold ${
                        i < 7 ? 'bg-emerald-500/80 text-white' : 'bg-white/10 text-white/50'
                      }`}
                    >
                      {day}
                    </div>
                  ))}
                </div>
              </div>

              {/* Profile card */}
              <div className="bg-white rounded-2xl border border-dark-100 p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary-500 to-emerald-500 flex items-center justify-center text-white text-sm font-bold shadow-lg">
                    {initials}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-dark-900">{user?.fullName}</p>
                    <p className="text-xs text-dark-400">{user?.email}</p>
                  </div>
                </div>
                <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dark-200 text-sm font-medium text-dark-700 hover:bg-dark-50 hover:border-primary-200 transition-all">
                  <User className="w-4 h-4" />
                  Profilni tahrirlash
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
