import { motion } from 'framer-motion';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { Star, Clock, Users, ArrowRight, BookOpen } from 'lucide-react';

interface CoursesProps {
  onNavigate: (page: 'landing' | 'login' | 'register' | 'dashboard') => void;
}

const courses = [
  {
    title: 'Farmakologiya asoslari',
    description: 'Dori vositalari ta\'siri mexanizmlari, farmakokinetika va farmakodynamikani chuqur o\'rganing.',
    image: 'https://images.pexels.com/photos/8667961/pexels-photo-8667961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    modules: 12,
    lessons: 48,
    students: 3240,
    rating: 4.9,
    level: 'Boshlang\'ich',
    duration: '40 soat',
    tag: 'Eng mashhur',
    tagColor: 'bg-amber-100 text-amber-700',
  },
  {
    title: 'Klinik farmatsiya',
    description: 'Bemorlarni davolashda farmasevtning roli, dori o\'zaro ta\'siri va dozalash tamoyillarini o\'rganing.',
    image: 'https://images.pexels.com/photos/8666446/pexels-photo-8666446.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    modules: 16,
    lessons: 64,
    students: 2180,
    rating: 4.8,
    level: 'O\'rta',
    duration: '56 soat',
    tag: 'Yangi',
    tagColor: 'bg-emerald-100 text-emerald-700',
  },
  {
    title: 'Farmatsevtik texnologiya',
    description: 'Dori shakllarini ishlab chiqarish, sifat nazorati va zamonaviy texnologiyalarni o\'rganing.',
    image: 'https://images.pexels.com/photos/3772620/pexels-photo-3772620.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
    modules: 14,
    lessons: 56,
    students: 1850,
    rating: 4.9,
    level: 'Ilg\'or',
    duration: '48 soat',
    tag: 'Premium',
    tagColor: 'bg-primary-100 text-primary-700',
  },
];

export default function Courses({ onNavigate }: CoursesProps) {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section id="courses" ref={ref} className="py-20 sm:py-28 bg-dark-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 border border-emerald-100 text-sm font-medium text-emerald-700 mb-5"
          >
            <BookOpen className="w-4 h-4" />
            Kurslar
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-dark-900 tracking-tight mb-5"
          >
            Eng mashhur <span className="gradient-text">kurslarimiz</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-dark-500 leading-relaxed"
          >
            Tajribali ekspertlar tomonidan tayyorlangan, amaliyotga yo'naltirilgan kurslar bilan bilimingizni mustahkamlang.
          </motion.p>
        </div>

        {/* Course cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, i) => (
            <motion.div
              key={course.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.1 }}
              className="group bg-white rounded-3xl border border-dark-100 overflow-hidden hover:shadow-2xl hover:shadow-primary-500/[0.08] hover:border-primary-200 transition-all duration-500"
            >
              {/* Image */}
              <div className="relative h-52 overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                <span className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold ${course.tagColor}`}>
                  {course.tag}
                </span>
                <div className="absolute bottom-4 right-4 flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-sm">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-semibold text-dark-800">{course.rating}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs font-medium text-primary-600 bg-primary-50 px-2.5 py-1 rounded-md">
                    {course.level}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-dark-400">
                    <Clock className="w-3.5 h-3.5" />
                    {course.duration}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-dark-900 mb-2 group-hover:text-primary-700 transition-colors">
                  {course.title}
                </h3>
                <p className="text-sm text-dark-500 leading-relaxed mb-4">
                  {course.description}
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-dark-100">
                  <div className="flex items-center gap-4 text-xs text-dark-400">
                    <span>{course.modules} modul</span>
                    <span>{course.lessons} dars</span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {course.students.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View all link */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-12"
        >
          <button
            onClick={() => onNavigate('register')}
            className="group inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-primary-600 hover:text-primary-700 border border-primary-200 hover:border-primary-300 rounded-xl hover:bg-primary-50 transition-all duration-200"
          >
            Barcha kurslarni ko'rish
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
