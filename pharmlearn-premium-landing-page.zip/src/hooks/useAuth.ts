import { useState, useEffect, createContext, useContext } from 'react';

export interface User {
  id: string;
  fullName: string;
  email: string;
  avatar?: string;
  role: string;
  joinedAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isAuthenticated: boolean;
}

export interface RegisterData {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  specialization?: string;
  agreeTerms: boolean;
}

const AUTH_KEY = 'pharmlearn_auth';
const USERS_KEY = 'pharmlearn_users';

function getStoredUsers(): Array<{ email: string; password: string; fullName: string; phone?: string; specialization?: string; createdAt: string }> {
  try {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function storeUser(user: { email: string; password: string; fullName: string; phone?: string; specialization?: string; createdAt: string }) {
  const users = getStoredUsers();
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function useAuthProvider(): AuthContextType {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(AUTH_KEY);
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {
      // ignore
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    // Simulate network delay
    await new Promise((r) => setTimeout(r, 1200));

    const users = getStoredUsers();
    const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());

    if (!found) {
      setIsLoading(false);
      return { success: false, error: 'Bu email bilan foydalanuvchi topilmadi' };
    }

    if (found.password !== password) {
      setIsLoading(false);
      return { success: false, error: 'Parol noto\'g\'ri. Qaytadan urinib ko\'ring' };
    }

    const loggedUser: User = {
      id: btoa(found.email),
      fullName: found.fullName,
      email: found.email,
      role: 'Farmasevt',
      joinedAt: found.createdAt,
    };

    setUser(loggedUser);
    localStorage.setItem(AUTH_KEY, JSON.stringify(loggedUser));
    setIsLoading(false);
    return { success: true };
  };

  const register = async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1500));

    const users = getStoredUsers();
    const exists = users.find((u) => u.email.toLowerCase() === data.email.toLowerCase());

    if (exists) {
      setIsLoading(false);
      return { success: false, error: 'Bu email allaqachon ro\'yxatdan o\'tgan' };
    }

    const newUserData = {
      email: data.email,
      password: data.password,
      fullName: data.fullName,
      phone: data.phone,
      specialization: data.specialization,
      createdAt: new Date().toISOString(),
    };

    storeUser(newUserData);

    const loggedUser: User = {
      id: btoa(data.email),
      fullName: data.fullName,
      email: data.email,
      role: data.specialization || 'Farmasevt',
      joinedAt: newUserData.createdAt,
    };

    setUser(loggedUser);
    localStorage.setItem(AUTH_KEY, JSON.stringify(loggedUser));
    setIsLoading(false);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(AUTH_KEY);
  };

  return {
    user,
    isLoading,
    login,
    register,
    logout,
    isAuthenticated: !!user,
  };
}

// Context (will be used in App)
export const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
